let baseConfig = require('./webpack.config');

module.exports = Object.assign({}, baseConfig, {});