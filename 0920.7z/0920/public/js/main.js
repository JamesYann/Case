$(function() { 
        $("#sortable").sortable(     
        {opacity: 0.7,
            update :function(event,ui){
                // var getData = $(this).sortable('toArray').toString();
                // //var newOrder = "567899"

                var count = 1;
                
                $("#sortable").find(".card").each(function(index, element){
                    var id = $(this).attr("id");                    
                    // $("#result_box").append(id+"<br />");

                    // var data = count;
                    // var type = 'dddd';
                     var data = {
                        place_id : id,
                        order_no : count
                     };

                    $.ajax({
                        type:'post',
                        url: '/schedule/insert',
                        data : data,
                        dataType : JSON                                       
                    });
                    count++;
                });
             

                //  alert(getData);
                // // console.log(getData); 

                // $.ajax({
                //     type:'get',
                //     url: '/schedule/insert',
                //     data : getData
                // });

                // put_result(ui);

            }
            // , 
            // cursor: 'crosshair',  
            // update : function () {  
            //     var ckitm = $( "#ckItem" ).sortable('toArray').toString();  
            // // if(ckitm=="on"){ 
            // //         var order = $('#sortable').sortable('serialize'); 
            // // } 
            //     var sitem = $( "#item" ).val(); 
                    
            //     //alert(order); 
            //         $("#info").load("update-order.asp?"+order+"&vitem="+sitem+"&ckitem="+ckitm);  
            // } 
        });  
    }); 

    function put_result(ui){
        $("#result_box").html("現在の要素のIDの順番は下記のとおりです。<br />");
        
        $("#sortable").find(".card").each(function(index, element){
            var id = $(this).attr("id");
            $("#result_box").append(id+"<br />");
        });
     
        if(ui){ // もしドラッグ後であれば
            // ドラッグされた要素のIDを取得
            var dragged_id = ui.item[0].id;
            $("#result_box").append("ドラッグされた要素のIDは"+dragged_id+"です<br />");
        }
    }